/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef ATMEL_START_PINS_H_INCLUDED
#define ATMEL_START_PINS_H_INCLUDED

#include <hal_gpio.h>

// SAMD21 has 8 pin functions

#define GPIO_PIN_FUNCTION_A 0
#define GPIO_PIN_FUNCTION_B 1
#define GPIO_PIN_FUNCTION_C 2
#define GPIO_PIN_FUNCTION_D 3
#define GPIO_PIN_FUNCTION_E 4
#define GPIO_PIN_FUNCTION_F 5
#define GPIO_PIN_FUNCTION_G 6
#define GPIO_PIN_FUNCTION_H 7

#define X_ALERT GPIO(GPIO_PORTA, 5)
#define Y_ALERT GPIO(GPIO_PORTA, 6)
#define Z_ALERT GPIO(GPIO_PORTA, 7)
#define SDA GPIO(GPIO_PORTA, 8)
#define SCL GPIO(GPIO_PORTA, 9)
#define Normal_LED GPIO(GPIO_PORTA, 12)
#define Error_LED GPIO(GPIO_PORTA, 13)
#define IN_CAPT_A GPIO(GPIO_PORTA, 14)
#define DRV_STEP_PWM GPIO(GPIO_PORTA, 15)
#define DRV_HOME GPIO(GPIO_PORTA, 16)
#define DRV_MODE2 GPIO(GPIO_PORTA, 17)
#define DRV_MODE1 GPIO(GPIO_PORTA, 18)
#define DRV_MODE0 GPIO(GPIO_PORTA, 19)
#define DRV_ENABLE GPIO(GPIO_PORTA, 20)
#define DRV_DIR GPIO(GPIO_PORTA, 21)
#define DRV_SLEEP GPIO(GPIO_PORTA, 24)
#define DRV_RESET GPIO(GPIO_PORTA, 25)
#define IRQ_SYNC GPIO(GPIO_PORTA, 27)
#define DONE GPIO(GPIO_PORTA, 28)
#define IRQ_LS_A GPIO(GPIO_PORTB, 2)
#define IRQ_LS_B GPIO(GPIO_PORTB, 3)
#define PB08 GPIO(GPIO_PORTB, 8)
#define PB09 GPIO(GPIO_PORTB, 9)
#define PB10 GPIO(GPIO_PORTB, 10)
#define PB11 GPIO(GPIO_PORTB, 11)

#endif // ATMEL_START_PINS_H_INCLUDED

#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	// set normal LED to show that device has been programmed
	gpio_set_pin_level(Error_LED, false);
	
	PWM_0_example();
	
	I2C_0_example();

	/* Replace with your application code */
	while (1) {
	}
	
}
